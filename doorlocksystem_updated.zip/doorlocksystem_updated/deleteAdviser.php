<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'rfidattendance');

if(isset($_POST['deletedata']))
{
    $profID = $_POST['delete_id'];

    $query = "DELETE FROM prof_tbl WHERE profID='$profID'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header("Location:manageProf.php");
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
    }
}

?>
