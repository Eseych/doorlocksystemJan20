<?php
require "connectDB.php";

    if(isset($_POST['updatedata']))
    {
        $profID = $_POST['update_id'];
        $profName = $_POST['profName'];
        $profEmail = $_POST['profEmail'];
        $profPass = $_POST['profPass'];

        $query = "UPDATE prof_tbl SET profName='$profName', profEmail='$profEmail', profPass='$profPass' WHERE profID='$profID'  ";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            echo '<script> alert("Data Updated"); </script>';
            header("Location:manageProf.php");
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>
