<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Manage Organization</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/manageorg.css">
    <link rel="stylesheet" type="text/css" href="css/Users.css">
      <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  	<script src="https://code.jquery.com/jquery-3.3.1.js"
  	        integrity="sha1256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  	        crossorigin="anonymous">
  	</script>
      <script type="text/javascript" src="js/bootbox.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>

</head>
<body >
  <?php include'header.php'; ?>
  <main>
    <h1>Manage Organization</h1>
  	<div class="form-style-5 slideInDown animated">
  		<form method="POST" name="addOrganizationFrm" id="addOrganizationFrm">
  			<div class="alert_user"></div>
  			<fieldset>
  				<legend><span class="number">1</span> Organization Info</legend>
  				<input type="hidden" name="orgID" id="orgID">
  				<input type="text" name="orgName"  placeholder="Organization Name..." required>
  			</fieldset>
        <fieldset>
          <label for="active"><b>Status</b></label>
  				<input type="radio" name="isActive" value="1" checked="checked">Active
  	       <input type="radio" name="isActive"  value="0" >Not Active
  			</fieldset>
  			<button type="submit" id ="addOrgBtn" name="addOrgBtn" class="btn btn-primary">Add Organization</button>
  		</form>
  	</div>
  <!--############################################################################# -->
  <!-- EDIT POP UP FORM (Bootstrap MODAL) -->

  <div class="modal fade" id="editOrgmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel"> Edit Organization/Club Data </h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>

              <form method="POST">

                  <div class="modal-body">

                      <input type="hidden" name="update_id_Org" id="update_id_Org">

                      <div class="form-group">
                          <label> Organization/Club Name </label>
                          <input type="text" name="orgName" id="orgName" class="form-control"
                              placeholder="Enter Organization/Club Name">
                      </div>
                      <fieldset>
                        <label for="active"><b>Status</b></label>
                				<input type="radio" name="isActive"  value="1" checked ="checked">Active
                	       <input type="radio" name="isActive"  value="0" checked ="checked">Not Active
                			</fieldset>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" name="updateorgdata" class="btn btn-primary">Update Data</button>
                  </div>
              </form>
          </div>
      </div>
  </div>

<!--############################################################################# -->

<!-- DELETE POP UP FORM (Bootstrap MODAL) -->
  <div class="modal fade" id="deleteOrgmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel"> Delete Organization/Club Data </h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>

              <form method="POST">

                  <div class="modal-body">

                      <input type="hidden" name="delete_id_org" id="delete_id_org">

                      <h4> Do you want to Delete this Data?</h4>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                      <button type="submit" name="deleteorgdata" class="btn btn-primary"> YES </button>
                  </div>
              </form>

          </div>
      </div>
  </div>

<!--############################################################################# -->

    <div class="section">
        <!--User table-->
        <div class="table-responsive-sm slideInRight animated" style="max-height: 37.5rem">
          <table class="table">
            <thead class="table-primary">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Students</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="table-secondary">
              <br>
           <?php
                //Connect to database
                $sql = "SELECT org_tbl.orgID, org_tbl.orgName, COUNT(student_tbl.orgName) as org_count, org_tbl.isActive
                          FROM org_tbl
                          LEFT JOIN student_tbl
                          ON org_tbl.orgName = student_tbl.orgName
                          GROUP BY org_tbl.orgName";
                          $result = mysqli_query($conn, $sql);
                          while($row = mysqli_fetch_assoc($result)) { ?>
                          <tr>
                            <td><?php echo $row['orgID']; ?></td>
                            <td><?php echo $row['orgName']; ?></td>
                            <td><?php echo $row['org_count']; ?></td>
                            <td>
                        <?php
                          echo ($row['isActive']==1) ? "ACTIVE" : "INACTIVE";
                        ?>
                      </td>
                            <td>
                              <button type="button" class="btn btn-success editbtn" > EDIT</button>
                              <button type="button" class="btn btn-danger deletebtn"> DELETE </button>
                            </td>
                            </form>
                          </TR>
              <?php
                      }
              ?>
            </tbody>
          </table>
        </div>
    </div>

    <script>
         $(document).ready(function () {

             $('.deletebtn').on('click', function () {

                 $('#deleteOrgmodal').modal('show');

                 $tr = $(this).closest('tr');

                 var data = $tr.children("td").map(function () {
                     return $(this).text();
                 }).get();

                 console.log(data);

                 $('#delete_id_org').val(data[0]);

             });
         });
     </script>

     <script>
          $(document).ready(function () {

              $('.editbtn').on('click', function () {

                  $('#editOrgmodal').modal('show');

                  $tr = $(this).closest('tr');

                  var data = $tr.children("td").map(function () {
                      return $(this).text();
                  }).get();

                  console.log(data);

                  $('#update_id_Org').val(data[0]);
                  $('#orgName').val(data[1]);
                  $('#isActive').val(data[3]);

              });
          });
      </script>

  </main>
  <?php
    include ('connectDB.php');

    if(isset($_POST['addOrgBtn'])){
      $nameTxt = $_POST['orgName'];
      $isActive = $_POST['isActive'];

      $addAppointmentQuery = "INSERT INTO `org_tbl`(`orgName`, `isActive`)
      VALUES ('$nameTxt','$isActive')";
      $result = mysqli_query($conn, $addAppointmentQuery);
      if($result)
      {
        echo "Data inserted";
        }
      else {
        echo "Error";
      }
      echo "<script>window.location.replace('manageOrg.php')</script>";

      exit();
    }
  ?>

</body>

<!--############################################################################# -->
<!--Update Adviser php-->
<?php
if(isset($_POST['updateorgdata']))
    {
        $orgID = $_POST['update_id_Org'];
        $orgName = $_POST['orgName'];
        $isActive = (isset($_POST['isActive'])) ? $_POST['isActive'] : 0;

        if (!empty($orgName)) {
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "UPDATE org_tbl SET orgName=?, isActive=? WHERE orgID=?";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
                echo "SQL Error";
            } else {
                mysqli_stmt_bind_param($stmt, "sii", $orgName, $isActive, $orgID);
                echo "<script>alert('Organization/Club has been updated.'); setTimeout(function(){ window.location.href='manageOrg.php'; }, 200);</script>";
                mysqli_stmt_execute($stmt);
                echo 1;
            }
            mysqli_close($conn);
        }
    }
    ?>
<!--############################################################################# -->
<!--Delete Adviser php-->
<?php
if(isset($_POST['deleteorgdata']))
{
    $orgID = $_POST['delete_id_org'];

    $query = "DELETE FROM org_tbl WHERE orgID='$orgID'";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        echo "<script>window.location.replace('manageOrg.php')</script>";
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
    }
}

?>


</html>
