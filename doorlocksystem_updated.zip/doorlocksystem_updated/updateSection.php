<?php
    // Connect to the database
    require 'connectDB.php';

    // Retrieve the form data
    $sectionID = $_POST['sectionID'];
    $sectionName = $_POST['sectionName'];
    $sectionCapacity = $_POST['sectionCapacity'];
    $isActive = $_POST['isActive'];

    // Build the update query
    $sql = "UPDATE section_tbl SET sectionName='$sectionName', sectionCapacity='$sectionCapacity', isActive='$isActive' WHERE sectionID='$sectionID'";

    // Execute the update query
    if (mysqli_query($conn, $sql)) {
        // Update was successful, redirect back to the manage sections page
        header('Location: manageSections.php');
    } else {
        // Update was not successful, show an error message
        echo "Error updating record: " . mysqli_error($conn);
    }
    // Close the database connection
    mysqli_close($conn);
?>
