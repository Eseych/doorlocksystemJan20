-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2023 at 11:34 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidattendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `admin_email` varchar(80) NOT NULL,
  `adminPass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_email`, `adminPass`) VALUES
(1, 'Lienard', 'ld@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointedsection`
--

CREATE TABLE `appointedsection` (
  `appointmentId` int(11) NOT NULL,
  `sectionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointedsection`
--

INSERT INTO `appointedsection` (`appointmentId`, `sectionID`) VALUES
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 2),
(40, 1),
(41, 2),
(42, 5),
(43, 5),
(44, 4),
(45, 4),
(46, 5),
(47, 5),
(48, 5),
(49, 4),
(50, 5),
(51, 4),
(52, 2),
(53, 4),
(54, 4),
(55, 4),
(56, 2),
(57, 5),
(58, 6),
(59, 9),
(60, 8),
(65, 6),
(66, 6),
(67, 6),
(68, 6),
(69, 8),
(70, 5),
(71, 6),
(72, 6),
(73, 5),
(74, 8),
(75, 9),
(76, 8),
(77, 8),
(78, 5),
(79, 6),
(80, 8),
(81, 9),
(82, 8),
(83, 8),
(84, 9),
(85, 8),
(86, 13),
(87, 14),
(88, 15),
(89, 13),
(90, 13),
(91, 14),
(92, 14),
(93, 18),
(94, 13),
(95, 15),
(96, 15),
(97, 13),
(98, 13),
(99, 12),
(100, 17),
(101, 15);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_tbl`
--

CREATE TABLE `appointment_tbl` (
  `appointmentID` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `timeStart` time NOT NULL,
  `timeEnd` time NOT NULL,
  `reason` text NOT NULL,
  `isActive` int(1) NOT NULL,
  `profName` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_tbl`
--

INSERT INTO `appointment_tbl` (`appointmentID`, `name`, `email`, `date`, `timeStart`, `timeEnd`, `reason`, `isActive`, `profName`, `status`) VALUES
(79, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-13', '18:01:00', '23:00:00', 'asdas', 1, '', 0),
(82, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-13', '09:39:00', '09:40:00', 'asdas', 1, '', 0),
(83, 'Emman Elefante', 'johnlienard.diaz@gmail.com', '2023-01-14', '09:30:00', '17:00:00', 'asdasd', 1, '', 0),
(86, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-15', '12:15:00', '16:05:00', 'asdas', 1, '', 0),
(89, 'l3nard11', 'johnlienardd@gmail.com', '2023-01-18', '10:36:00', '10:40:00', 'dasd', 1, '', 0),
(93, 'Taguro', 'johnlienardd@gmail.com', '2023-01-16', '15:12:00', '16:14:00', 'Trip lang ', 1, '', 0),
(94, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-17', '09:37:00', '10:37:00', 'asd', 1, '1', 0),
(95, 'gagokaba', 'johnlienard.diaz@gmail.com', '2023-01-19', '09:45:00', '11:42:00', 'asdasd', 1, '1', 0),
(96, 'asdasdasd', 'johnlienard.diaz@gmail.com', '2023-01-20', '16:48:00', '16:54:00', 'asdasd', 1, '1', 0),
(99, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-21', '09:46:00', '10:42:00', 'asdas', 1, 'jeromeaustria@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `device_name` varchar(50) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `device_uid` text NOT NULL,
  `device_date` date NOT NULL,
  `device_mode` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_name`, `device_dep`, `device_uid`, `device_date`, `device_mode`) VALUES
(1, 'LAPTOP-ADMIN', 'AVR', '1ee77e62596b1010', '2022-12-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `head_tbl`
--

CREATE TABLE `head_tbl` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `head_tbl`
--

INSERT INTO `head_tbl` (`ID`, `name`, `email`, `pass`) VALUES
(1, 'Miss A', 'a@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `org_tbl`
--

CREATE TABLE `org_tbl` (
  `orgID` int(11) NOT NULL,
  `orgName` varchar(50) NOT NULL,
  `sectionName` varchar(50) NOT NULL,
  `isActive` int(11) NOT NULL,
  `org_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `org_tbl`
--

INSERT INTO `org_tbl` (`orgID`, `orgName`, `sectionName`, `isActive`, `org_count`) VALUES
(5, 'Computer Society', '0', 1, 0),
(6, 'HM Society', 'BSIT212', 1, 0),
(11, 'kalokohan', 'BSIT311', 1, 0),
(12, 'Student Council', 'BSBA 311', 1, 1),
(13, 'Student Councilss', '', 1, 0),
(14, 'SYMS', '', 1, 0),
(15, 'CS', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `prof_tbl`
--

CREATE TABLE `prof_tbl` (
  `profID` int(11) NOT NULL,
  `profName` varchar(50) NOT NULL,
  `profEmail` varchar(50) NOT NULL,
  `profPass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prof_tbl`
--

INSERT INTO `prof_tbl` (`profID`, `profName`, `profEmail`, `profPass`) VALUES
(1, 'Jerome Austria', 'jeromeaustria@gmail.com', '123Jerome');

-- --------------------------------------------------------

--
-- Table structure for table `schoolyr_tbl`
--

CREATE TABLE `schoolyr_tbl` (
  `schoolyear_ID` int(11) NOT NULL,
  `term` varchar(50) NOT NULL,
  `isActive` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `section_tbl`
--

CREATE TABLE `section_tbl` (
  `sectionID` int(11) NOT NULL,
  `schoolyrID` int(11) NOT NULL,
  `sectionName` varchar(50) NOT NULL,
  `isActive` int(1) NOT NULL,
  `student_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section_tbl`
--

INSERT INTO `section_tbl` (`sectionID`, `schoolyrID`, `sectionName`, `isActive`, `student_count`) VALUES
(12, 0, 'BSIT211', 1, 0),
(13, 0, 'BSIT711', 1, 1),
(14, 0, 'BSIT811', 1, 1),
(15, 0, 'BSIT311', 1, 0),
(16, 0, 'BSIT212', 1, 0),
(17, 0, 'BSIT213', 1, 0),
(18, 0, 'BSBA 111', 1, 1),
(19, 0, 'BSBA 211', 1, 1),
(20, 0, 'BSBA 311', 1, 1),
(21, 0, 'BASBA 411', 1, 0),
(22, 0, 'BSBA 411', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

CREATE TABLE `student_tbl` (
  `studentID` int(11) NOT NULL,
  `studentNumber` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `sectionID` varchar(50) NOT NULL,
  `orgName` varchar(50) NOT NULL,
  `card_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`studentID`, `studentNumber`, `firstName`, `lastName`, `sectionID`, `orgName`, `card_uid`) VALUES
(1, 123123, 'lienard ', 'diaz', 'BSIT711', 'HM', 0),
(2, 123, 'sofia ', 'hiwatig', 'BSIT711', 'CS', 0),
(3, 123, 'joshuel ', 'ilagan', 'BSIT711', 'cs', 0),
(4, 123123, 'camille', 'san jose', 'BSIT711', 'cs', 0),
(5, 123123, 'asdasd', 'asdas', 'BAst123', 'hm', 0),
(6, 12312312, 'sdas', 'gago', 'Bs123', 'mh', 0),
(7, 1312312, 'asdasd', 'boboak', 'bs123', 'mh', 0),
(8, 123123, 'tangina', 'ayawgumana', 'bs123', 'mh', 0),
(9, 123123, 'sdas', 'asdasd', 'basdasdas123', 'mh', 0),
(10, 12312312, 'leszo', 'gagoo', 'Bs12321', 'mh', 0),
(11, 12312, 'hatdog123', 'hhahah', 'bstaba', '', 0),
(12, 12312312, 'asdasd', 'adssa', '123ac', 'cs', 0),
(13, 123123, 'John Lienard', 'Diaz', 'BSIT211', 'Computer Society', 0),
(14, 1231234554, 'Sofia', 'Hiwatig', 'BSIT711', 'Computer Society', 0),
(15, 2147483647, 'john', 'Diaz', 'BSIT211', 'HM Society', 0),
(16, 9239, 'JOHN', 'DIAZ', 'BSIT211', 'asdasd', 0),
(17, 2147483647, 'John Lienard', 'knrz', 'BSIT811', 'HM Society', 0),
(18, 919, 'John Lienard', 'Hiwatig', 'BSIT711', 'Computer Society', 0),
(19, 2000072777, 'Katy ', 'Goodwin', 'BSIT 111', 'CS', 0),
(20, 2000015845, 'Emmy ', 'Oconnell', 'ABM 112', 'SUMS', 0),
(21, 2000072594, 'Marvin ', 'Mcgowan', 'BSHM 711', 'ACE', 0),
(22, 2000032014, 'Donovan ', 'Francis', 'BSBA 111', 'SYMS', 0),
(23, 2000026845, 'Simeon ', 'Simmons', 'HUMSS 112', 'ACE', 0),
(24, 2000033733, 'Iestyn ', 'Massey', 'ABM 112', 'SUMS', 0),
(25, 2000027087, 'Moshe ', 'Taylor', 'BSHM 711', 'ACE', 0),
(26, 2000068699, 'Arman ', 'Hampton', 'BSHM 711', 'SC', 0),
(27, 2000002793, 'Benjamin ', 'Mayo', 'SHS 111', 'ACE', 0),
(28, 2000058671, 'Angus ', 'Chavez', 'BSIT 311', 'CS', 0),
(29, 2000024837, 'Maryam ', 'Hurst', 'BSHM 611', 'SC', 0),
(30, 2000045874, 'Dewi ', 'Rivers', 'ABM 112', 'SUMS', 0),
(31, 2000074829, 'Kade ', 'Freeman', 'BSIT 311', 'CS', 0),
(32, 2000097394, 'Maya ', 'Turner', 'BSIT 711', 'SC', 0),
(33, 2000007067, 'Cole ', 'Brady', 'CCTEC 212', 'ACE', 0),
(34, 2000056040, 'Liliana ', 'Joyce', 'BSIT 411', 'CS', 0),
(35, 2000021797, 'Diana ', 'Bryant', 'BSBA 611', 'SYMS', 0),
(36, 2000003555, 'Aamir ', 'Sanders', 'BSHM 311', 'HM', 0),
(37, 2000040171, 'Libbie ', 'Adams', 'BSIT 211', 'CS', 0),
(38, 2000099854, 'Caiden ', 'Crosby', 'BSHM 311', 'HM', 0),
(39, 2000019281, 'Erica ', 'Wright', 'BSHM 611', 'SC', 0),
(40, 2000029533, 'Nabil ', 'Levy', 'BSBA 711', 'SYMS', 0),
(41, 2000062165, 'Alexandre ', 'Alvarez', 'BSIT 411', 'CS', 0),
(42, 2000063288, 'Joan ', 'Schaefer', 'BSBA 211', 'SYMS', 0),
(43, 2000001714, 'Luna ', 'Sanchez', 'BSBA 411', 'SC', 0),
(44, 2000082969, 'Marissa ', 'Cantu', 'BSIT 711', 'SC', 0),
(45, 2000015894, 'Marwa ', 'Romero', 'BSHM 111', 'HM', 0),
(46, 2000031568, 'Eleanor ', 'Bryan', 'BSIT 511', 'CS', 0),
(47, 2000014641, 'Ehsan ', 'Barry', 'BSIT 611', 'CS', 0),
(48, 2000033220, 'Aishah ', 'Berry', 'BSHM 511', 'HM', 0),
(49, 2000077455, 'Aidan ', 'Carroll', 'BSBA 411', 'SC', 0),
(50, 2000012471, 'Homer ', 'Hayes', 'BSIT 611', 'CS', 0),
(51, 2000016011, 'Tomos ', 'Thompson', 'BSBA 511', 'SYMS', 0),
(52, 2000006908, 'Tony ', 'Solomon', 'BSHM 111', 'HM', 0),
(53, 2000058826, 'Jonty ', 'Olson', 'BSHM 211', 'HM', 0),
(54, 2000007076, 'Isha ', 'Kent', 'BSBA 711', 'SC', 0),
(55, 2000022357, 'Tina ', 'Calderon', 'BSHM 411', 'HM', 0),
(56, 2000065287, 'Jean ', 'Horton', 'BSIT 511', 'CS', 0),
(57, 2000096762, 'Raja ', 'Richards', 'BSHM 211', 'HM', 0),
(58, 2000027226, 'Sallie ', 'Cisneros', 'BSBA 711', 'SC', 0),
(59, 2000057925, 'Gideon ', 'Mendoza', 'BSIT 711', 'SC', 0),
(60, 2000047194, 'Hari ', 'Ochoa', 'BSBA 411', 'SYMS', 0),
(61, 2000017430, 'Mohammad  ', 'Duffy', 'ABM 112', 'SUMS', 0),
(62, 2000028758, 'Oliwia ', 'Cortez', 'BSHM 511', 'HM', 0),
(63, 2000081499, 'Anastasia ', 'Baldwin', 'BSIT 111', 'CS', 0),
(64, 2000021217, 'Aoife ', 'Cross', 'ABM 112', 'ACE', 0),
(65, 2000073476, 'Lula ', 'Ayala', 'BSBA 311', 'SYMS', 0),
(66, 2000003721, 'Shannon ', 'Mcknight', 'ITMAWD 212', 'ACE', 0),
(67, 91958, 'hahahah', 'Diaz', 'BSBA 311', '0', 0),
(68, 123123, 'lienard ', 'diaz', 'BSIT711', 'HM', 0),
(69, 123, 'sofia ', 'hiwatig', 'BSIT711', 'CS', 0),
(70, 123, 'joshuel ', 'ilagan', 'BSIT711', 'cs', 0),
(71, 123123, 'camille', 'san jose', 'BSIT711', 'cs', 0),
(72, 123123, 'asdasd', 'asdas', 'BAst123', 'hm', 0),
(73, 12312312, 'sdas', 'gago', 'Bs123', 'mh', 0),
(74, 1312312, 'asdasd', 'boboak', 'bs123', 'mh', 0),
(75, 123123, 'tangina', 'ayawgumana', 'bs123', 'mh', 0),
(76, 123123, 'sdas', 'asdasd', 'basdasdas123', 'mh', 0),
(77, 12312312, 'leszo', 'gagoo', 'Bs12321', 'mh', 0),
(78, 12312, 'hatdog123', 'hhahah', 'bstaba', '', 0),
(79, 12312312, 'asdasd', 'adssa', '123ac', 'cs', 0),
(80, 123123, 'lienard ', 'diaz', 'BSIT711', 'HM', 0),
(81, 123, 'sofia ', 'hiwatig', 'BSIT711', 'CS', 0),
(82, 123, 'joshuel ', 'ilagan', 'BSIT711', 'cs', 0),
(83, 123123, 'camille', 'san jose', 'BSIT711', 'cs', 0),
(84, 123123, 'asdasd', 'asdas', 'BAst123', 'hm', 0),
(85, 12312312, 'sdas', 'gago', 'Bs123', 'mh', 0),
(86, 1312312, 'asdasd', 'boboak', 'bs123', 'mh', 0),
(87, 123123, 'tangina', 'ayawgumana', 'bs123', 'mh', 0),
(88, 123123, 'sdas', 'asdasd', 'basdasdas123', 'mh', 0),
(89, 12312312, 'leszo', 'gagoo', 'Bs12321', 'mh', 0),
(90, 12312, 'hatdog123', 'hhahah', 'bstaba', '', 0),
(91, 12312312, 'asdasd', 'adssa', '123ac', 'cs', 0),
(92, 2000072777, 'Katy ', 'Goodwin', 'BSIT 111', 'CS', 0),
(93, 2000015845, 'Emmy ', 'Oconnell', 'ABM 112', 'SUMS', 0),
(94, 2000072594, 'Marvin ', 'Mcgowan', 'BSHM 711', 'ACE', 0),
(95, 2000032014, 'Donovan ', 'Francis', 'BSBA 111', 'SYMS', 0),
(96, 2000026845, 'Simeon ', 'Simmons', 'HUMSS 112', 'ACE', 0),
(97, 2000033733, 'Iestyn ', 'Massey', 'ABM 112', 'SUMS', 0),
(98, 2000027087, 'Moshe ', 'Taylor', 'BSHM 711', 'ACE', 0),
(99, 2000068699, 'Arman ', 'Hampton', 'BSHM 711', 'SC', 0),
(100, 2000002793, 'Benjamin ', 'Mayo', 'SHS 111', 'ACE', 0),
(101, 2000058671, 'Angus ', 'Chavez', 'BSIT 311', 'CS', 0),
(102, 2000024837, 'Maryam ', 'Hurst', 'BSHM 611', 'SC', 0),
(103, 2000045874, 'Dewi ', 'Rivers', 'ABM 112', 'SUMS', 0),
(104, 2000074829, 'Kade ', 'Freeman', 'BSIT 311', 'CS', 0),
(105, 2000097394, 'Maya ', 'Turner', 'BSIT 711', 'SC', 0),
(106, 2000007067, 'Cole ', 'Brady', 'CCTEC 212', 'ACE', 0),
(107, 2000056040, 'Liliana ', 'Joyce', 'BSIT 411', 'CS', 0),
(108, 2000021797, 'Diana ', 'Bryant', 'BSBA 611', 'SYMS', 0),
(109, 2000003555, 'Aamir ', 'Sanders', 'BSHM 311', 'HM', 0),
(110, 2000040171, 'Libbie ', 'Adams', 'BSIT 211', 'CS', 0),
(111, 2000099854, 'Caiden ', 'Crosby', 'BSHM 311', 'HM', 0),
(112, 2000019281, 'Erica ', 'Wright', 'BSHM 611', 'SC', 0),
(113, 2000029533, 'Nabil ', 'Levy', 'BSBA 711', 'SYMS', 0),
(114, 2000062165, 'Alexandre ', 'Alvarez', 'BSIT 411', 'CS', 0),
(115, 2000063288, 'Joan ', 'Schaefer', 'BSBA 211', 'SYMS', 0),
(116, 2000001714, 'Luna ', 'Sanchez', 'BSBA 411', 'SC', 0),
(117, 2000082969, 'Marissa ', 'Cantu', 'BSIT 711', 'SC', 0),
(118, 2000015894, 'Marwa ', 'Romero', 'BSHM 111', 'HM', 0),
(119, 2000031568, 'Eleanor ', 'Bryan', 'BSIT 511', 'CS', 0),
(120, 2000014641, 'Ehsan ', 'Barry', 'BSIT 611', 'CS', 0),
(121, 2000033220, 'Aishah ', 'Berry', 'BSHM 511', 'HM', 0),
(122, 2000077455, 'Aidan ', 'Carroll', 'BSBA 411', 'SC', 0),
(123, 2000012471, 'Homer ', 'Hayes', 'BSIT 611', 'CS', 0),
(124, 2000016011, 'Tomos ', 'Thompson', 'BSBA 511', 'SYMS', 0),
(125, 2000006908, 'Tony ', 'Solomon', 'BSHM 111', 'HM', 0),
(126, 2000058826, 'Jonty ', 'Olson', 'BSHM 211', 'HM', 0),
(127, 2000007076, 'Isha ', 'Kent', 'BSBA 711', 'SC', 0),
(128, 2000022357, 'Tina ', 'Calderon', 'BSHM 411', 'HM', 0),
(129, 2000065287, 'Jean ', 'Horton', 'BSIT 511', 'CS', 0),
(130, 2000096762, 'Raja ', 'Richards', 'BSHM 211', 'HM', 0),
(131, 2000027226, 'Sallie ', 'Cisneros', 'BSBA 711', 'SC', 0),
(132, 2000057925, 'Gideon ', 'Mendoza', 'BSIT 711', 'SC', 0),
(133, 2000047194, 'Hari ', 'Ochoa', 'BSBA 411', 'SYMS', 0),
(134, 2000017430, 'Mohammad  ', 'Duffy', 'ABM 112', 'SUMS', 0),
(135, 2000028758, 'Oliwia ', 'Cortez', 'BSHM 511', 'HM', 0),
(136, 2000081499, 'Anastasia ', 'Baldwin', 'BSIT 111', 'CS', 0),
(137, 2000021217, 'Aoife ', 'Cross', 'ABM 112', 'ACE', 0),
(138, 2000073476, 'Lula ', 'Ayala', 'BSBA 311', 'SYMS', 0),
(139, 2000003721, 'Shannon ', 'Mcknight', 'ITMAWD 212', 'ACE', 0),
(140, 123123, 'lienard ', 'diaz', 'BSIT711', 'HM', 0),
(141, 123, 'sofia ', 'hiwatig', 'BSIT711', 'CS', 0),
(142, 123, 'joshuel ', 'ilagan', 'BSIT711', 'cs', 0),
(143, 123123, 'camille', 'san jose', 'BSIT711', 'cs', 0),
(144, 123123, 'asdasd', 'asdas', 'BAst123', 'hm', 0),
(145, 12312312, 'sdas', 'gago', 'Bs123', 'mh', 0),
(146, 1312312, 'asdasd', 'boboak', 'bs123', 'mh', 0),
(147, 123123, 'tangina', 'ayawgumana', 'bs123', 'mh', 0),
(148, 123123, 'sdas', 'asdasd', 'basdasdas123', 'mh', 0),
(149, 12312312, 'leszo', 'gagoo', 'Bs12321', 'mh', 0),
(150, 12312, 'hatdog123', 'hhahah', 'bstaba', '', 0),
(151, 12312312, 'asdasd', 'adssa', '123ac', 'cs', 0),
(152, 91293175, 'AKO LANG TO', 'DIAZ', 'BSBA 211', 'Student Council', 0),
(153, 2147483647, 'John Lienard', 'Diaz', 'BSBA 111', '0', 0),
(154, 2000001714, 'Aamir ', 'Adams', 'BSIT 211', 'CS', 0),
(155, 2000002793, 'Aidan ', 'Alvarez', 'BSIT 211', 'CS', 0),
(156, 2000003555, 'Aishah ', 'Ayala', 'BSIT 211', 'CS', 0),
(157, 2000003721, 'Alexandre ', 'Baldwin', 'BSIT 211', 'CS', 0),
(158, 2000006908, 'Anastasia ', 'Barry', 'BSIT 211', 'CS', 0),
(159, 2000007067, 'Angus ', 'Berry', 'BSIT 711', 'CS', 0),
(160, 2000007076, 'Aoife ', 'Brady', 'BSIT 711', 'CS', 0),
(161, 2000012471, 'Arman ', 'Bryan', 'BSIT 711', 'CS', 0),
(162, 2000014641, 'Benjamin ', 'Bryant', 'BSIT 711', 'CS', 0),
(163, 2000015845, 'Caiden ', 'Calderon', 'BSIT 711', 'CS', 0),
(164, 2000015894, 'Cole ', 'Cantu', 'BSIT 811', 'CS', 0),
(165, 2000016011, 'Dewi ', 'Carroll', 'BSIT 811', 'CS', 0),
(166, 2000017430, 'Diana ', 'Chavez', 'BSIT 811', 'CS', 0),
(167, 2000019281, 'Donovan ', 'Cisneros', 'BSIT 811', 'CS', 0),
(168, 2000021217, 'Ehsan ', 'Cortez', 'BSIT 811', 'CS', 0),
(169, 2000021797, 'Eleanor ', 'Crosby', 'BSIT 311', 'CS', 0),
(170, 2000022357, 'Emmy ', 'Cross', 'BSIT 311', 'CS', 0),
(171, 2000024837, 'Erica ', 'Duffy', 'BSIT 311', 'CS', 0),
(172, 2000026845, 'Gideon ', 'Francis', 'BSIT 311', 'CS', 0),
(173, 2000027087, 'Hari ', 'Freeman', 'BSIT 311', 'CS', 0),
(174, 2000027226, 'Homer ', 'Goodwin', 'BSIT 212', 'CS', 0),
(175, 2000028758, 'Honor ', 'Hampton', 'BSIT 212', 'CS', 0),
(176, 2000029533, 'Iestyn ', 'Hayes', 'BSIT 212', 'CS', 0),
(177, 2000031568, 'Isha ', 'Horton', 'BSIT 212', 'CS', 0),
(178, 2000032014, 'Jean ', 'Hurst', 'BSIT 212', 'CS', 0),
(179, 2000033220, 'Joan ', 'Joyce', 'BSIT 213', 'CS', 0),
(180, 2000033733, 'Jonty ', 'Kent', 'BSIT 213', 'CS', 0),
(181, 2000040171, 'Kade ', 'Levy', 'BSIT 213', 'CS', 0),
(182, 2000045874, 'Katy ', 'Massey', 'BSIT 213', 'CS', 0),
(183, 2000047194, 'Libbie ', 'Mayo', 'BSIT 213', 'CS', 0),
(184, 2000054807, 'Liliana ', 'Mcgowan', 'BSBA 111', 'SYMS', 0),
(185, 2000056040, 'Lilly', 'Mcknight', 'BSBA 111', 'SYMS', 0),
(186, 2000057925, 'Lula ', 'Mendoza', 'BSBA 111', 'SYMS', 0),
(187, 2000058671, 'Luna ', 'Ochoa', 'BSBA 111', 'SYMS', 0),
(188, 2000058826, 'Marissa ', 'Oconnell', 'BSBA 111', 'SYMS', 0),
(189, 2000062165, 'Marvin ', 'Olson', 'BSBA 211', 'SYMS', 0),
(190, 2000068699, 'Maya ', 'Richards', 'BSBA 211', 'SYMS', 0),
(191, 2000071639, 'Mohammad  ', 'Rivers', 'BSBA 211', 'SYMS', 0),
(192, 2000072594, 'Moshe ', 'Romero', 'BSBA 311', 'SYMS', 0),
(193, 2000072777, 'Nabil ', 'Sanchez', 'BSBA 311', 'SYMS', 0),
(194, 2000073476, 'Oliwia ', 'Sanders', 'BSBA 311', 'SYMS', 0),
(195, 2000074829, 'Raja ', 'Schaefer', 'BSBA 311', 'SYMS', 0),
(196, 2000077455, 'Sallie ', 'Simmons', 'BSBA 311', 'SYMS', 0),
(197, 2000081499, 'Shannon ', 'Solomon', 'BSBA 411', 'SYMS', 0),
(198, 2000082969, 'Simeon ', 'Taylor', 'BSBA 411', 'SYMS', 0),
(199, 2000096762, 'Tina ', 'Thompson', 'BSBA 411', 'SYMS', 0),
(200, 2000097394, 'Tomos ', 'Turner', 'BSBA 411', 'SYMS', 0),
(201, 2000099854, 'Tony ', 'Wright', 'BSBA 411', 'SYMS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT 'None',
  `serialnumber` double NOT NULL DEFAULT 0,
  `sectionName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT 'None',
  `card_uid` varchar(30) NOT NULL,
  `card_select` tinyint(1) NOT NULL DEFAULT 0,
  `user_date` date NOT NULL,
  `device_uid` varchar(20) NOT NULL DEFAULT '0',
  `device_dep` varchar(20) NOT NULL DEFAULT '0',
  `add_card` tinyint(1) NOT NULL DEFAULT 0,
  `gender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `serialnumber`, `sectionName`, `email`, `card_uid`, `card_select`, `user_date`, `device_uid`, `device_dep`, `add_card`, `gender`) VALUES
(11, 'abdc', 2132131, '', 'lienard@gmail.com', '8214545239', 0, '2023-01-10', '1ee77e62596b1010', 'AVR', 1, 0),
(12, 'hattdog', 21312312, 'None', 'lienar@gmail.com', '1838219045', 0, '2023-01-13', '1ee77e62596b1010', 'AVR', 1, 0),
(13, 'None', 0, '', 'None', '13115513425', 0, '2023-01-13', '08149bb13f36eaaa', 'hatsofd', 0, 0),
(14, 'leianrd', 123213, '', 'lienarddiax@gmail.asdas', '155181243118', 1, '2023-01-14', '1ee77e62596b1010', 'AVR', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_logs`
--

CREATE TABLE `users_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `serialnumber` double NOT NULL,
  `card_uid` varchar(30) NOT NULL,
  `device_uid` varchar(20) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `checkindate` date NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL,
  `card_out` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_logs`
--

INSERT INTO `users_logs` (`id`, `username`, `serialnumber`, `card_uid`, `device_uid`, `device_dep`, `checkindate`, `timein`, `timeout`, `card_out`) VALUES
(1, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '07:09:37', '13:11:07', 1),
(2, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:12:54', '13:13:07', 1),
(3, 'Joshuel', 19999231299, '8214545239', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:19:33', '13:20:25', 1),
(4, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:19:57', '13:20:15', 1),
(5, 'Joshuel', 19999231299, '8214545239', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:36:26', '13:36:36', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  ADD PRIMARY KEY (`appointmentID`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `head_tbl`
--
ALTER TABLE `head_tbl`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `org_tbl`
--
ALTER TABLE `org_tbl`
  ADD PRIMARY KEY (`orgID`);

--
-- Indexes for table `prof_tbl`
--
ALTER TABLE `prof_tbl`
  ADD PRIMARY KEY (`profID`);

--
-- Indexes for table `schoolyr_tbl`
--
ALTER TABLE `schoolyr_tbl`
  ADD PRIMARY KEY (`schoolyear_ID`);

--
-- Indexes for table `section_tbl`
--
ALTER TABLE `section_tbl`
  ADD PRIMARY KEY (`sectionID`);

--
-- Indexes for table `student_tbl`
--
ALTER TABLE `student_tbl`
  ADD PRIMARY KEY (`studentID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_logs`
--
ALTER TABLE `users_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  MODIFY `appointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `head_tbl`
--
ALTER TABLE `head_tbl`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `org_tbl`
--
ALTER TABLE `org_tbl`
  MODIFY `orgID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `prof_tbl`
--
ALTER TABLE `prof_tbl`
  MODIFY `profID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schoolyr_tbl`
--
ALTER TABLE `schoolyr_tbl`
  MODIFY `schoolyear_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `section_tbl`
--
ALTER TABLE `section_tbl`
  MODIFY `sectionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student_tbl`
--
ALTER TABLE `student_tbl`
  MODIFY `studentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users_logs`
--
ALTER TABLE `users_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
