<?php
include ('connectDB.php');
if(isset($_POST['filterBtn'])){
    $query = "CREATE TEMPORARY TABLE temp_student_tbl AS (SELECT DISTINCT * FROM student_tbl);
    TRUNCATE student_tbl;
    INSERT INTO student_tbl SELECT * FROM temp_student_tbl;";
    $result = $conn->query($query);
    if($result)
    {
        echo "Duplicate records removed";
    }
    else {
        echo "Error";
    }
}
?>
