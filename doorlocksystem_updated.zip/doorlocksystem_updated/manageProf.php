<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Manage Professors</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/manageprof.css">
    <link rel="stylesheet" type="text/css" href="css/Users.css">
      <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  	<script src="https://code.jquery.com/jquery-3.3.1.js"
  	        integrity="sha1256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  	        crossorigin="anonymous">
  	</script>
      <script type="text/javascript" src="js/bootbox.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>

</head>
<body >
  <?php include'header.php'; ?>
  <main>
    <h1>Manage Professors</h1>
  	<div class="form-style-5 slideInDown animated">
  		<form method="POST" name="addProfFrm" id="addProfFrm">
  			<div class="alert_user"></div>
  			<fieldset>
  				<legend><span class="number">1</span> Professors Information</legend>
  				<input type="hidden" name="profID" id="profID">
  				<input type="text" name="profName"  placeholder="Professors Name..." required>
  				<input type="text" name="profEmail"  placeholder="Professors Email..." required>
          <input type="text" name="profPass"  placeholder="Professors Password..." required>
  			</fieldset>

  			<button type="submit" id ="profBtn" name="profBtn" class="btn btn-primary">Add Professor</button>
  		</form>
  	</div>

    <!--############################################################################# -->
    <!-- EDIT POP UP FORM (Bootstrap MODAL) -->

    <div class="modal fade" id="editProfmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Edit Adviser Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="update_id_Prof" id="update_id_Prof">

                        <div class="form-group">
                            <label> Adviser Name </label>
                            <input type="text" name="profName" id="profName" class="form-control"
                                placeholder="Enter Adviser Name">
                        </div>

                        <div class="form-group">
                            <label> Adviser Email </label>
                            <input type="text" name="profEmail" id="profEmail" class="form-control"
                                placeholder="Enter Adviser Email">
                        </div>
                        <div class="form-group">
                            <label> Adviser Password </label>
                            <input type="text" name="profPass" id="profPass" class="form-control"
                                placeholder="Enter Adviser Password">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="updateprofdata" class="btn btn-primary">Update Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

  <!--############################################################################# -->

  <!-- DELETE POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="deleteProfmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Delete Adviser Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="delete_id_prof" id="delete_id_prof">

                        <h4> Do you want to Delete this Data?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deleteprofdata" class="btn btn-primary"> YES </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

  <!--############################################################################# -->

    <div class="section">
        <!--User table-->
        <div class="table-responsive-sm slideInRight animated" style="max-height: 37.5rem">
          <table class="table">
            <thead class="table-primary">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="table-secondary">
              <br>
           <?php
                //Connect to database
                require'connectDB.php';
                  $sql = "SELECT * FROM prof_tbl ORDER BY profID DESC";
                  $result = mysqli_query($conn, $sql);
                  while($row = mysqli_fetch_assoc($result))
                  {
                ?>
                            <TR>
                            <TD><?php echo $row['profID'];?></TD>
                            <TD><?php echo $row['profName'];?></TD>
                            <TD><?php echo $row['profEmail'];?></TD>
                            <TD><?php echo $row['profPass'];?></TD>
                            <td>
                              <button type="button" class="btn btn-success editbtn"> EDIT</button>
                              <button type="button" class="btn btn-danger deletebtn"> DELETE </button>
                            </td>
                            </form>
                          </TR>
              <?php
                      }
              ?>
            </tbody>
          </table>
        </div>
    </div>


  <script>
       $(document).ready(function () {

           $('.deletebtn').on('click', function () {

               $('#deleteProfmodal').modal('show');

               $tr = $(this).closest('tr');

               var data = $tr.children("td").map(function () {
                   return $(this).text();
               }).get();

               console.log(data);

               $('#delete_id_prof').val(data[0]);

           });
       });
   </script>
   <script>
        $(document).ready(function () {

            $('.editbtn').on('click', function () {

                $('#editProfmodal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function () {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#update_id_Prof').val(data[0]);
                $('#profName').val(data[1]);
                $('#profEmail').val(data[2]);
                $('#profPass').val(data[3]);

            });
        });
    </script>

  </main>
  <?php
    include ('connectDB.php');

    if(isset($_POST['profBtn'])){
      $profName = $_POST['profName'];
      $profEmail = $_POST['profEmail'];
      $profPass = $_POST['profPass'];

      // echo $nameTxt;
      $check_student_number = "SELECT * FROM prof_tbl WHERE profName='$profName'";
      $result = $conn->query($check_student_number);
      if ($result->num_rows > 0) {
        // student number already exists in the database
        echo  "<script>alert('Prof is already in the database'); setTimeout(function(){ window.location.href='manageStudents.php'; }, 200);</script>";

      }else {
        $addProfQuery = "INSERT INTO `prof_tbl`(`profName`, `profEmail`, `profPass`) VALUES
         ('$profName','$profEmail','$profPass')";
        $result = mysqli_query($conn, $addProfQuery);
        if($result)
        {
          echo "Data inserted";
        }else {
          echo "Error";
        }
      }
      echo "<script>window.location.replace('manageProf.php')</script>";
      exit();
    }
  ?>
</body>
<!--############################################################################# -->
<!--Update Adviser php-->
<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'rfidattendance');

    if(isset($_POST['updateprofdata']))
    {
        $profID = $_POST['update_id_Prof'];
        $profName = $_POST['profName'];
        $profEmail = $_POST['profEmail'];
        $profPass = $_POST['profPass'];

        $query = "UPDATE prof_tbl SET profName='$profName', profEmail='$profEmail', profPass='$profPass' WHERE profID='$profID'  ";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            echo "<script>window.location.replace('manageProf.php')</script>";
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>
<!--############################################################################# -->
<!--Delete Adviser php-->
<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'rfidattendance');

if(isset($_POST['deletedata']))
{
    $profID = $_POST['delete_id_prof'];

    $query = "DELETE FROM prof_tbl WHERE profID='$profID'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        echo "<script>window.location.replace('manageProf.php')</script>";
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
    }
}

?>


</html>
