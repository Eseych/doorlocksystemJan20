-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2023 at 08:45 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidattendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `admin_email` varchar(80) NOT NULL,
  `adminPass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_email`, `adminPass`) VALUES
(1, 'Lienard', 'ld@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointedsection`
--

CREATE TABLE `appointedsection` (
  `appointmentId` int(11) NOT NULL,
  `sectionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointedsection`
--

INSERT INTO `appointedsection` (`appointmentId`, `sectionID`) VALUES
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 2),
(40, 1),
(41, 2),
(42, 5),
(43, 5),
(44, 4),
(45, 4),
(46, 5),
(47, 5),
(48, 5),
(49, 4),
(50, 5),
(51, 4),
(52, 2),
(53, 4),
(54, 4),
(55, 4),
(56, 2),
(57, 5),
(58, 6),
(59, 9),
(60, 8),
(65, 6),
(66, 6),
(67, 6),
(68, 6),
(69, 8),
(70, 5),
(71, 6),
(72, 6),
(73, 5),
(74, 8),
(75, 9),
(76, 8),
(77, 8),
(78, 5),
(79, 6),
(80, 8),
(81, 9),
(82, 8),
(83, 8),
(84, 9),
(85, 8),
(86, 13),
(87, 14),
(88, 15),
(89, 13),
(90, 13),
(91, 14),
(92, 14),
(93, 18),
(94, 13),
(95, 15),
(96, 15),
(97, 13),
(98, 13),
(99, 12),
(100, 17),
(101, 15);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_tbl`
--

CREATE TABLE `appointment_tbl` (
  `appointmentID` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `timeStart` time NOT NULL,
  `timeEnd` time NOT NULL,
  `reason` text NOT NULL,
  `isActive` int(1) NOT NULL,
  `profName` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `signatories` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_tbl`
--

INSERT INTO `appointment_tbl` (`appointmentID`, `name`, `email`, `date`, `timeStart`, `timeEnd`, `reason`, `isActive`, `profName`, `status`, `signatories`) VALUES
(79, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-13', '18:01:00', '23:00:00', 'asdas', 1, '', 0, ''),
(82, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-13', '09:39:00', '09:40:00', 'asdas', 1, '', 0, ''),
(83, 'Emman Elefante', 'johnlienard.diaz@gmail.com', '2023-01-14', '09:30:00', '17:00:00', 'asdasd', 1, '', 0, ''),
(86, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-15', '12:15:00', '16:05:00', 'asdas', 1, '', 0, ''),
(89, 'l3nard11', 'johnlienardd@gmail.com', '2023-01-18', '10:36:00', '10:40:00', 'dasd', 1, '', 0, ''),
(93, 'Taguro', 'johnlienardd@gmail.com', '2023-01-16', '15:12:00', '16:14:00', 'Trip lang ', 1, '', 0, ''),
(94, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-17', '09:37:00', '10:37:00', 'asd', 1, '1', 0, ''),
(95, 'gagokaba', 'johnlienard.diaz@gmail.com', '2023-01-19', '09:45:00', '11:42:00', 'asdasd', 1, '1', 0, ''),
(96, 'asdasdasd', 'johnlienard.diaz@gmail.com', '2023-01-20', '16:48:00', '16:54:00', 'asdasd', 1, '1', 0, ''),
(99, 'lienard diaz', 'johnlienard.diaz@gmail.com', '2023-01-21', '09:46:00', '10:42:00', 'asdas', 1, 'jeromeaustria@gmail.com', 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `device_name` varchar(50) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `device_uid` text NOT NULL,
  `device_date` date NOT NULL,
  `device_mode` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_name`, `device_dep`, `device_uid`, `device_date`, `device_mode`) VALUES
(1, 'LAPTOP-ADMIN', 'AVR', '1ee77e62596b1010', '2022-12-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `head_tbl`
--

CREATE TABLE `head_tbl` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `head_tbl`
--

INSERT INTO `head_tbl` (`ID`, `name`, `email`, `pass`) VALUES
(1, 'Miss A', 'a@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `org_tbl`
--

CREATE TABLE `org_tbl` (
  `orgID` int(11) NOT NULL,
  `orgName` varchar(50) NOT NULL,
  `sectionName` varchar(50) NOT NULL,
  `isActive` int(11) NOT NULL,
  `org_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `org_tbl`
--

INSERT INTO `org_tbl` (`orgID`, `orgName`, `sectionName`, `isActive`, `org_count`) VALUES
(5, 'Computer Society', '0', 1, 1),
(6, 'HM Society', 'BSIT212', 1, 1),
(11, 'kalokohan', 'BSIT311', 1, 1),
(12, 'Student Council', 'BSBA 311', 1, 1),
(13, 'Student Councilss', '', 1, 1),
(14, 'SYMS', '', 1, 0),
(15, 'CS', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `prof_tbl`
--

CREATE TABLE `prof_tbl` (
  `profID` int(11) NOT NULL,
  `profName` varchar(50) NOT NULL,
  `profEmail` varchar(50) NOT NULL,
  `profPass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prof_tbl`
--

INSERT INTO `prof_tbl` (`profID`, `profName`, `profEmail`, `profPass`) VALUES
(1, 'Jerome Austria', 'jeromeaustria@gmail.com', '123Jerome'),
(13, 'lienard', 'johnlienard.diaz@gmail.com', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `schoolyr_tbl`
--

CREATE TABLE `schoolyr_tbl` (
  `schoolyear_ID` int(11) NOT NULL,
  `term` varchar(50) NOT NULL,
  `isActive` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `section_tbl`
--

CREATE TABLE `section_tbl` (
  `sectionID` int(11) NOT NULL,
  `schoolyrID` int(11) NOT NULL,
  `sectionName` varchar(50) NOT NULL,
  `isActive` int(1) NOT NULL,
  `student_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section_tbl`
--

INSERT INTO `section_tbl` (`sectionID`, `schoolyrID`, `sectionName`, `isActive`, `student_count`) VALUES
(12, 0, 'BSIT211', 1, 0),
(13, 0, 'BSIT711', 1, 3),
(14, 0, 'BSIT811', 1, 1),
(15, 0, 'BSIT311', 1, 0),
(16, 0, 'BSIT212', 1, 1),
(17, 0, 'BSIT213', 1, 0),
(18, 0, 'BSBA 111', 1, 2),
(19, 0, 'BSBA 211', 1, 1),
(20, 0, 'BSBA 311', 1, 1),
(21, 0, 'BASBA 411', 0, 0),
(22, 0, 'BSBA 411', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_logs`
--

CREATE TABLE `student_logs` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `studentNumber` int(11) NOT NULL,
  `card_uid` varchar(30) NOT NULL,
  `device_uid` varchar(20) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `checkindate` date NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL,
  `card_out` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

CREATE TABLE `student_tbl` (
  `studentID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL DEFAULT 'None',
  `lastName` varchar(50) DEFAULT 'None',
  `studentNumber` int(11) NOT NULL DEFAULT 0,
  `card_uid` varchar(30) CHARACTER SET latin1 NOT NULL,
  `card_select` tinyint(1) NOT NULL DEFAULT 0,
  `device_uid` varchar(20) NOT NULL DEFAULT '0',
  `add_card` tinyint(1) NOT NULL DEFAULT 0,
  `device_dep` varchar(30) NOT NULL DEFAULT '0',
  `orgName` varchar(50) NOT NULL DEFAULT 'None',
  `sectionID` varchar(50) NOT NULL DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`studentID`, `firstName`, `lastName`, `studentNumber`, `card_uid`, `card_select`, `device_uid`, `add_card`, `device_dep`, `orgName`, `sectionID`) VALUES
(263, 'None', 'None', 0, '17147153160', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(264, 'None', 'None', 0, '1838219045', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(265, 'None', 'None', 0, '318619023', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(266, 'None', 'None', 0, '1232319160', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(267, 'None', 'None', 0, '219108168118', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(268, 'None', 'None', 0, '43252211118', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(269, 'None', 'None', 0, '8214545239', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(270, 'None', 'None', 0, '27176155118', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(271, 'None', 'None', 0, '155106148118', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(272, 'None', 'None', 0, '155181243118', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(273, 'None', 'None', 0, '13115513425', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(274, 'None', 'None', 0, '11224139160', 0, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(275, 'None', 'None', 0, '281892773', 1, '1ee77e62596b1010', 0, 'AVR', 'None', 'None'),
(276, 'John Lienard', 'Diaz', 1231234554, '', 0, '0', 0, '0', 'Computer Society', 'BSIT711'),
(277, 'John Lienard', 'Hiwatig', 123123, '', 0, '0', 0, '0', 'HM Society', 'BSIT711'),
(278, 'Aamir ', 'Adams', 2000001714, '', 0, '', 0, '', 'CS', 'BSIT 211'),
(279, 'Aidan ', 'Alvarez', 2000002793, '', 0, '', 0, '', 'CS', 'BSIT 211'),
(280, 'Aishah ', 'Ayala', 2000003555, '', 0, '', 0, '', 'CS', 'BSIT 211'),
(281, 'Alexandre ', 'Baldwin', 2000003721, '', 0, '', 0, '', 'CS', 'BSIT 211'),
(282, 'Anastasia ', 'Barry', 2000006908, '', 0, '', 0, '', 'CS', 'BSIT 211'),
(283, 'Angus ', 'Berry', 2000007067, '', 0, '', 0, '', 'CS', 'BSIT 711'),
(284, 'Aoife ', 'Brady', 2000007076, '', 0, '', 0, '', 'CS', 'BSIT 711'),
(285, 'Arman ', 'Bryan', 2000012471, '', 0, '', 0, '', 'CS', 'BSIT 711'),
(286, 'Benjamin ', 'Bryant', 2000014641, '', 0, '', 0, '', 'CS', 'BSIT 711'),
(287, 'Caiden ', 'Calderon', 2000015845, '', 0, '', 0, '', 'CS', 'BSIT 711'),
(288, 'Cole ', 'Cantu', 2000015894, '', 0, '', 0, '', 'CS', 'BSIT 811'),
(289, 'Dewi ', 'Carroll', 2000016011, '', 0, '', 0, '', 'CS', 'BSIT 811'),
(290, 'Diana ', 'Chavez', 2000017430, '', 0, '', 0, '', 'CS', 'BSIT 811'),
(291, 'Donovan ', 'Cisneros', 2000019281, '', 0, '', 0, '', 'CS', 'BSIT 811'),
(292, 'Ehsan ', 'Cortez', 2000021217, '', 0, '', 0, '', 'CS', 'BSIT 811'),
(293, 'Eleanor ', 'Crosby', 2000021797, '', 0, '', 0, '', 'CS', 'BSIT 311'),
(294, 'Emmy ', 'Cross', 2000022357, '', 0, '', 0, '', 'CS', 'BSIT 311'),
(295, 'Erica ', 'Duffy', 2000024837, '', 0, '', 0, '', 'CS', 'BSIT 311'),
(296, 'Gideon ', 'Francis', 2000026845, '', 0, '', 0, '', 'CS', 'BSIT 311'),
(297, 'Hari ', 'Freeman', 2000027087, '', 0, '', 0, '', 'CS', 'BSIT 311'),
(298, 'Homer ', 'Goodwin', 2000027226, '', 0, '', 0, '', 'CS', 'BSIT 212'),
(299, 'Honor ', 'Hampton', 2000028758, '', 0, '', 0, '', 'CS', 'BSIT 212'),
(300, 'Iestyn ', 'Hayes', 2000029533, '', 0, '', 0, '', 'CS', 'BSIT 212'),
(301, 'Isha ', 'Horton', 2000031568, '', 0, '', 0, '', 'CS', 'BSIT 212'),
(302, 'Jean ', 'Hurst', 2000032014, '', 0, '', 0, '', 'CS', 'BSIT 212'),
(303, 'Joan ', 'Joyce', 2000033220, '', 0, '', 0, '', 'CS', 'BSIT 213'),
(304, 'Jonty ', 'Kent', 2000033733, '', 0, '', 0, '', 'CS', 'BSIT 213'),
(305, 'Kade ', 'Levy', 2000040171, '', 0, '', 0, '', 'CS', 'BSIT 213'),
(306, 'Katy ', 'Massey', 2000045874, '', 0, '', 0, '', 'CS', 'BSIT 213'),
(307, 'Libbie ', 'Mayo', 2000047194, '', 0, '', 0, '', 'CS', 'BSIT 213'),
(308, 'Liliana ', 'Mcgowan', 2000054807, '', 0, '', 0, '', 'SYMS', 'BSBA 111'),
(309, 'Lilly', 'Mcknight', 2000056040, '', 0, '', 0, '', 'SYMS', 'BSBA 111'),
(310, 'Lula ', 'Mendoza', 2000057925, '', 0, '', 0, '', 'SYMS', 'BSBA 111'),
(311, 'Luna ', 'Ochoa', 2000058671, '', 0, '', 0, '', 'SYMS', 'BSBA 111'),
(312, 'Marissa ', 'Oconnell', 2000058826, '', 0, '', 0, '', 'SYMS', 'BSBA 111'),
(313, 'Marvin ', 'Olson', 2000062165, '', 0, '', 0, '', 'SYMS', 'BSBA 211'),
(314, 'Maya ', 'Richards', 2000068699, '', 0, '', 0, '', 'SYMS', 'BSBA 211'),
(315, 'Mohammad  ', 'Rivers', 2000071639, '', 0, '', 0, '', 'SYMS', 'BSBA 211'),
(316, 'Moshe ', 'Romero', 2000072594, '', 0, '', 0, '', 'SYMS', 'BSBA 311'),
(317, 'Nabil ', 'Sanchez', 2000072777, '', 0, '', 0, '', 'SYMS', 'BSBA 311'),
(318, 'Oliwia ', 'Sanders', 2000073476, '', 0, '', 0, '', 'SYMS', 'BSBA 311'),
(319, 'Raja ', 'Schaefer', 2000074829, '', 0, '', 0, '', 'SYMS', 'BSBA 311'),
(320, 'Sallie ', 'Simmons', 2000077455, '', 0, '', 0, '', 'SYMS', 'BSBA 311'),
(321, 'Shannon ', 'Solomon', 2000081499, '', 0, '', 0, '', 'SYMS', 'BSBA 411'),
(322, 'Simeon ', 'Taylor', 2000082969, '', 0, '', 0, '', 'SYMS', 'BSBA 411'),
(323, 'Tina ', 'Thompson', 2000096762, '', 0, '', 0, '', 'SYMS', 'BSBA 411'),
(324, 'Tomos ', 'Turner', 2000097394, '', 0, '', 0, '', 'SYMS', 'BSBA 411'),
(325, 'Tony ', 'Wright', 2000099854, '', 0, '', 0, '', 'SYMS', 'BSBA 411');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT 'None',
  `serialnumber` double NOT NULL DEFAULT 0,
  `email` varchar(50) NOT NULL DEFAULT 'None',
  `card_uid` varchar(30) NOT NULL,
  `card_select` tinyint(1) NOT NULL DEFAULT 0,
  `user_date` date NOT NULL,
  `device_uid` varchar(20) NOT NULL DEFAULT '0',
  `device_dep` varchar(20) NOT NULL DEFAULT '0',
  `add_card` tinyint(1) NOT NULL DEFAULT 0,
  `gender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `serialnumber`, `email`, `card_uid`, `card_select`, `user_date`, `device_uid`, `device_dep`, `add_card`, `gender`) VALUES
(11, 'abdc', 2132131, 'lienard@gmail.com', '8214545239', 0, '2023-01-10', '1ee77e62596b1010', 'AVR', 1, 0),
(12, 'hattdog', 21312312, 'lienar@gmail.com', '1838219045', 1, '2023-01-13', '1ee77e62596b1010', 'AVR', 1, 0),
(13, 'None', 0, 'None', '13115513425', 0, '2023-01-13', '08149bb13f36eaaa', 'hatsofd', 0, 0),
(14, 'leianrd', 123213, 'lienarddiax@gmail.asdas', '155181243118', 0, '2023-01-14', '1ee77e62596b1010', 'AVR', 1, 0),
(15, 'None', 0, 'None', '17147153160', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(16, 'None', 0, 'None', '155106148118', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(17, 'None', 0, 'None', '21953153160', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(18, 'None', 0, 'None', '27176155118', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(19, 'None', 0, 'None', '11224139160', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(20, 'None', 0, 'None', '171127108161', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(21, 'None', 0, 'None', '219108168118', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(22, 'None', 0, 'None', '1232319160', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0),
(23, 'None', 0, 'None', '43252211118', 0, '2023-01-18', '1ee77e62596b1010', 'AVR', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_logs`
--

CREATE TABLE `users_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `serialnumber` double NOT NULL,
  `card_uid` varchar(30) NOT NULL,
  `device_uid` varchar(20) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `checkindate` date NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL,
  `card_out` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_logs`
--

INSERT INTO `users_logs` (`id`, `username`, `serialnumber`, `card_uid`, `device_uid`, `device_dep`, `checkindate`, `timein`, `timeout`, `card_out`) VALUES
(1, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '07:09:37', '13:11:07', 1),
(2, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:12:54', '13:13:07', 1),
(3, 'Joshuel', 19999231299, '8214545239', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:19:33', '13:20:25', 1),
(4, 'Aris', 199999999, '9110325336', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:19:57', '13:20:15', 1),
(5, 'Joshuel', 19999231299, '8214545239', '1ee77e62596b1010', 'AVR', '2022-12-02', '13:36:26', '13:36:36', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  ADD PRIMARY KEY (`appointmentID`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `head_tbl`
--
ALTER TABLE `head_tbl`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `org_tbl`
--
ALTER TABLE `org_tbl`
  ADD PRIMARY KEY (`orgID`);

--
-- Indexes for table `prof_tbl`
--
ALTER TABLE `prof_tbl`
  ADD PRIMARY KEY (`profID`);

--
-- Indexes for table `schoolyr_tbl`
--
ALTER TABLE `schoolyr_tbl`
  ADD PRIMARY KEY (`schoolyear_ID`);

--
-- Indexes for table `section_tbl`
--
ALTER TABLE `section_tbl`
  ADD PRIMARY KEY (`sectionID`);

--
-- Indexes for table `student_logs`
--
ALTER TABLE `student_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_tbl`
--
ALTER TABLE `student_tbl`
  ADD PRIMARY KEY (`studentID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_logs`
--
ALTER TABLE `users_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  MODIFY `appointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `head_tbl`
--
ALTER TABLE `head_tbl`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `org_tbl`
--
ALTER TABLE `org_tbl`
  MODIFY `orgID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `prof_tbl`
--
ALTER TABLE `prof_tbl`
  MODIFY `profID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `schoolyr_tbl`
--
ALTER TABLE `schoolyr_tbl`
  MODIFY `schoolyear_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `section_tbl`
--
ALTER TABLE `section_tbl`
  MODIFY `sectionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student_logs`
--
ALTER TABLE `student_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_tbl`
--
ALTER TABLE `student_tbl`
  MODIFY `studentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=326;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users_logs`
--
ALTER TABLE `users_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
