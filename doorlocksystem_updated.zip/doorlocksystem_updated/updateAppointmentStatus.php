<?php
require 'connectDB.php';

if(isset($_POST['approve'])) {
    // get the appointment ID
    $appointmentID = $_POST['appointmentID'];
    // update the status of the appointment to "approved" (3)
    $updateQuery = "UPDATE appointment_tbl SET status = status + 1 WHERE appointmentID = $appointmentID";
    $result = mysqli_query($conn, $updateQuery);

    if($result) {
        // change the button HTML to show that the appointment is approved
        echo "<script>document.getElementById('approveBtn_$appointmentID').innerHTML = 'Approved';</script>";
        echo "<script>window.location.replace('indexSignatories.php')</script>";
    } else {
        echo "<script>alert('Error approving appointment.');</script>";
    }
}
?>
