$(document).ready(function(){
  // Add user
  $(document).on('click', '.user_add', function(){
    //user Info
    var user_id = $('#studentID').val();
    var fname = $('#firstName').val();
    var lname = $('#lastName').val();
    var number = $('#studentNumber').val();
    var section = $('#sectionSelect').val();
    var organization = $('#orgSelect').val();


    $.ajax({
      url: 'manage_student_conf.php',
      type: 'POST',
      data: {
        'Add': 1,
        'user_id': studentID,
        'fname': firstName,
        'lname': lastName,
        'number': studentNumber,
        'section': sectionID,
        'organization': orgName,
      },
      success: function(response){

        if (response == 1) {
          $('#studentID').val('');
          $('#firstName').val('');
          $('#lastName').val('');
          $('#studentNumber').val('');
          $('#sectionSelect').val('');
          $('#orgSelect').val('');

          $('.alert_user').html('<p class="alert alert-success">A new User has been successfully added</p>');
        }
        else{
          $('.alert_user').fadeIn(500);
          $('.alert_user').html('<p class="alert alert-danger">'+ response + '</p>');
        }

        setTimeout(function () {
            $('.alert').fadeOut(500);
        }, 5000);

        $.ajax({
          url: "manage_users_up.php"
          }).done(function(data) {
          $('#manage_student').html(data);
        });
      }
    });
  });

  // Update user
  $(document).on('click', '.user_upd', function(){
    var user_id = $('#studentID').val();
    var fname = $('#firstName').val();
    var lname = $('#lastName').val();
    var number = $('#studentNumber').val();
    var section = $('#sectionSelect').val();
    var organization = $('#orgSelect').val();

    $.ajax({
      url: 'manage_student_conf.php',
      type: 'POST',
      data: {
        'Update': 1,
        'user_id': studentID,
        'fname': firstName,
        'lname': lastName,
        'number': studentNumber,
        'section': sectionID,
        'organization': orgName,
      },
      success: function(response){

        if (response == 1) {
          $('#studentID').val('');
          $('#firstName').val('');
          $('#lastName').val('');
          $('#studentNumber').val('');
          $('#sectionSelect').val('');
          $('#orgSelect').val('');

          $('.alert_user').fadeIn(500);
          $('.alert_user').html('<p class="alert alert-success">The selected User has been updated!</p>');
        }
        else{
          $('.alert_user').fadeIn(500);
          $('.alert_user').html('<p class="alert alert-danger">'+ response + '</p>');
        }

        setTimeout(function () {
            $('.alert').fadeOut(500);
        }, 5000);

        $.ajax({
          url: "manage_student_up.php"
          }).done(function(data) {
          $('#manage_student').html(data);
        });
      }
    });
  });

  // delete user
  $(document).on('click', '.user_rmo', function(){

    var user_id = $('#studentID').val();

    bootbox.confirm("Do you really want to delete this User?", function(result) {
      if(result){
        $.ajax({
          url: 'manage_student_conf.php',
          type: 'POST',
          data: {
            'delete': 1,
            'user_id': studentID,
          },
          success: function(response){

            if (response == 1) {
              $('#studentID').val('');
              $('#firstName').val('');
              $('#lastName').val('');
              $('#studentNumber').val('');
              $('#sectionSelect').val('');
              $('#orgSelect').val('');

              $('.alert_user').fadeIn(500);
              $('.alert_user').html('<p class="alert alert-success">The selected User has been deleted!</p>');
            }
            else{
              $('.alert_user').fadeIn(500);
              $('.alert_user').html('<p class="alert alert-danger">'+ response + '</p>');
            }

            setTimeout(function () {
                $('.alert').fadeOut(500);
            }, 5000);

            $.ajax({
              url: "manage_student_up.php"
              }).done(function(data) {
              $('#manage_student').html(data);
            });
          }
        });
      }
    });
  });
  // select user
  $(document).on('click', '.select_btn', function(){
    var el = this;
    var card_uid = $(this).attr("id");
    $.ajax({
      url: 'manage_student_conf.php',
      type: 'GET',
      data: {
      'select': 1,
      'card_uid': card_uid,
      },
      success: function(response){

        $(el).closest('tr').css('background','#70c276');

        $('.alert_user').fadeIn(500);
        $('.alert_user').html('<p class="alert alert-success">The card has been selected!</p>');

        setTimeout(function () {
            $('.alert').fadeOut(500);
        }, 5000);

        $.ajax({
          url: "manage_student_up.php"
          }).done(function(data) {
          $('#manage_student').html(data);
        });

      },
      error : function(data) {
        console.log(data);
      }
    });
  });
});
