<?php
require 'connectDB.php'; // include the connection file to the database

$sectionID = $_POST['sectionID']; // retrieve the section ID from the AJAX request

$sql = "SELECT * FROM section_tbl WHERE sectionID = '$sectionID'"; // create a query to select the section details from the database
$result = mysqli_query($conn, $sql); // execute the query
$section = mysqli_fetch_assoc($result); // retrieve the section details as an associative array

echo json_encode($section); // return the section details as a JSON object
